# postfix

Base install of Postfix MTA from packages suitable
for delivery to remote relayhost.

Notes
-----
  * Tested on ::osfamily 'debian' and 'redhat'

License
-------
Apache License, Version 2.0

Contact
-------
Nathan Valentine - nrvale0@gmail.com

Support
-------
Please log tickets and issues at [the project's site](http://github.com/nrvale0/puppet-postfix).
